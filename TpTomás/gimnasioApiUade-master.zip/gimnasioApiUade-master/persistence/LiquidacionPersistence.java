package persistence;

public abstract class LiquidacionPersistence {
	public abstract void insert (Object o);
}