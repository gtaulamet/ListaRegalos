package persistence;

public abstract class DeportePersistence {
	public abstract void insert (Object o);
	public abstract void update (Object o);
	public abstract void delete (Object d);
}
