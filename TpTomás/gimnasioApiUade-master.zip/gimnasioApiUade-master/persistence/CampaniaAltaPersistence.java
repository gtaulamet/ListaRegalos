package persistence;

public abstract class CampaniaAltaPersistence {
	public abstract void insert (Object o);
}
